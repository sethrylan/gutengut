var fetch = require('node-fetch');

'use strict'

// var url = new URL(window.location.href),
//     start = parseInt(url.searchParams.get('start')) || 0,
//     limit = parseInt(url.searchParams.get('limit')) || 5;

var start = 0,
    limit = 5;

exports.handler = (event, context, callback) => {
  fetch('http://sethrylan.org/adventures.txt')
    .then(response => response.text())
    // .then(rawtext => rawtext.split('\n\n'))
    // .then(split => console.log(split.slice(1,2)))
    .then(rawtext => rawtext.split('\n\n').slice(start,start+limit).join('\n'))
    .then(text => callback(null, 'text'));
};
